# Assignment 1: Getting Started

## Instructions
Complete the tasks in this folder.

## Files to Create
- `assignment-01.ipynb` - Your main notebook
- `analysis.py` - Python analysis script

## Submission
Commit your work and push to GitHub.
